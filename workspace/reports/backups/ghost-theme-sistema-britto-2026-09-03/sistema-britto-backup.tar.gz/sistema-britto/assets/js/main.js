/* Sistema Britto — o JavaScript inteiro do tema.
 *
 * Regra que guiou o arquivo: se CSS resolve, CSS resolve. Sobrou o que depende
 * de estado que a folha de estilo não enxerga — posição de scroll, posição do
 * cursor e contagem de número. Tudo passivo, tudo com IntersectionObserver,
 * nada em loop de scroll.
 *
 * Sem dependência, sem build, ~2 KB. Carrega com `defer`: não bloqueia a
 * primeira pintura, e portanto não entra no caminho do LCP.
 */
(function () {
  'use strict';

  var reduzido = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* O menu hamburguer saiu junto com o botão: a navegação tem dois itens
     curtos e fica inline em qualquer largura. Esconder dois links atrás de um
     toque a mais não economizava espaço nenhum. */

  /* ── Borda da navegação ao rolar ─────────────────────────────────── */
  /* Uma sentinela de 1px no topo em vez de escutar scroll: o navegador avisa
     quando ela sai da tela, e não há handler rodando a cada pixel. */
  var nav = document.querySelector('[data-nav]');
  if (nav && 'IntersectionObserver' in window) {
    var sentinela = document.createElement('div');
    sentinela.style.cssText = 'position:absolute;top:0;height:1px;width:1px;pointer-events:none';
    document.body.prepend(sentinela);
    new IntersectionObserver(function (entradas) {
      nav.setAttribute('data-rolou', String(!entradas[0].isIntersecting));
    }).observe(sentinela);
  }

  /* ── Scroll reveal ───────────────────────────────────────────────── */
  var alvos = document.querySelectorAll('.revela');
  if (alvos.length && 'IntersectionObserver' in window && !reduzido) {
    // A classe no <html> é o que liga o estado inicial no CSS. Só entra aqui,
    // depois de confirmarmos que há observer — assim uma falha do script deixa
    // o conteúdo visível em vez de invisível.
    document.documentElement.classList.add('js-revela');

    var obs = new IntersectionObserver(function (entradas) {
      entradas.forEach(function (e) {
        if (!e.isIntersecting) return;
        e.target.classList.add('visivel');
        obs.unobserve(e.target);   // anima uma vez só
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.05 });

    alvos.forEach(function (el, i) {
      // Escada curta: dá ritmo sem atrasar o que já está na primeira dobra.
      el.style.transitionDelay = Math.min(i % 6, 5) * 55 + 'ms';
      obs.observe(el);
    });
  }

  /* ── Contador ────────────────────────────────────────────────────── */
  var contadores = document.querySelectorAll('[data-conta]');
  if (contadores.length && 'IntersectionObserver' in window) {
    var obsNum = new IntersectionObserver(function (entradas) {
      entradas.forEach(function (e) {
        if (!e.isIntersecting) return;
        obsNum.unobserve(e.target);
        anima(e.target);
      });
    }, { threshold: 0.4 });
    contadores.forEach(function (el) { obsNum.observe(el); });
  }

  function anima(el) {
    var alvo = parseFloat(el.getAttribute('data-conta'));
    if (isNaN(alvo)) return;
    var sufixo = el.getAttribute('data-sufixo') || '';
    if (reduzido) { el.textContent = formata(alvo) + sufixo; return; }

    var duracao = 1400;
    var inicio = null;
    function passo(agora) {
      if (inicio === null) inicio = agora;
      var p = Math.min((agora - inicio) / duracao, 1);
      var suave = 1 - Math.pow(1 - p, 3);         // easeOutCubic
      el.textContent = formata(alvo * suave) + sufixo;
      if (p < 1) requestAnimationFrame(passo);
    }
    requestAnimationFrame(passo);
  }

  function formata(n) {
    // Decimal só quando o alvo tem decimal: "99,9%" precisa, "247" não.
    return Number.isInteger(parseFloat(n.toFixed(1)))
      ? Math.round(n).toLocaleString('pt-BR')
      : n.toFixed(1).replace('.', ',');
  }

  /* ── Holofote do cartão ──────────────────────────────────────────── */
  /* Escreve duas custom properties no elemento; quem desenha o brilho é o CSS.
     Delegado no documento: um listener só, e cartões inseridos depois
     continuam funcionando. */
  if (window.matchMedia('(hover: hover)').matches) {
    document.addEventListener('pointermove', function (e) {
      var cartao = e.target.closest && e.target.closest('.cartao');
      if (!cartao) return;
      var r = cartao.getBoundingClientRect();
      cartao.style.setProperty('--x', (e.clientX - r.left) + 'px');
      cartao.style.setProperty('--y', (e.clientY - r.top) + 'px');
    }, { passive: true });
  }
})();
